Link to google drive checklist:
https://docs.google.com/document/d/18W8brLXRsFRSJ_3WzUoxaYX4IVnn-rtRACXUl0X-wCc/edit?usp=sharings
